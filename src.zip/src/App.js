import { Fragment, useState } from 'react';
import './App.css'; 
import 'remixicon/fonts/remixicon.css';
import { Link } from 'react-router-dom';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'; 
import homeImage from './assets/img/home.png';
import aboutImage from './assets/img/about.png';
import card1Image from './assets/img/card1.png';
import card2Image from './assets/img/card2.png';
import card3Image from './assets/img/card3.png';
import card4Image from './assets/img/card4.png';
import product1Image from './assets/img/product1.png';
import product2Image from './assets/img/product2.png';
import product3Image from './assets/img/product3.png';
import product4Image from './assets/img/product4.png';
import product5Image from './assets/img/product5.png';
import product6Image from './assets/img/product6.png';
import './Login/Login.css';
import Login from './Login/Login';
import Register from 'Login/Register';


function Home() {
  return (
    <Fragment>
    <section className="home" id="home">
          <div class="home__container container grid">
          <img src={homeImage} alt="" className="home__img" />


                    <div class="home__data">
                        <h1 class="home__title">
                            Plants will make  your life better
                        </h1>
                        <p class="home__description">
                            Create incredible plant design for your offices or apastaments. 
                            Add fresness to your new ideas.
                        </p>
                        <a href="#about" class="button button--flex">
                            Explore <i class="ri-arrow-right-down-line button__icon"></i>
                        </a>
                    </div>

                    <div class="home__social">
                        <span class="home__social-follow">Follow Us</span>

                        <div class="home__social-links">
                            <a href="https://www.facebook.com/" class="home__social-link">
                                <i class="ri-facebook-fill"></i>
                            </a>
                            <a href="https://www.instagram.com/" class="home__social-link">
                                <i class="ri-instagram-line"></i>
                            </a>
                            <a href="https://twitter.com/" class="home__social-link">
                                <i class="ri-twitter-fill"></i>
                            </a>
                        </div>
                    </div>
                </div>
    </section>
    </Fragment>
  );
}

function Screen(){
  return(
    <Fragment>
    <div className="App">
    <main className="main">
        <Home />
        {/* About Section */}
        <section className="about section container" id="about">
          <div className="about__container grid">
            <img src={aboutImage } alt="" className="about__img" />

            <div className="about__data">
              <h2 className="section__title about__title">
                Who we really are & <br /> why choose us
              </h2>

              <p className="about__description">
                We have over 4000+ unbiased reviews and our customers trust our plant process and delivery service every time
              </p>

              <div className="about__details">
                <p className="about__details-description">
                  <i className="ri-checkbox-fill about__details-icon"></i>
                  We always deliver on time.
                </p>
                <p className="about__details-description">
                  <i className="ri-checkbox-fill about__details-icon"></i>
                  We give you guides to protect and care for your plants.
                </p>
                <p className="about__details-description">
                  <i className="ri-checkbox-fill about__details-icon"></i>
                  We always come over for a check-up after sale.
                </p>
                <p className="about__details-description">
                  <i className="ri-checkbox-fill about__details-icon"></i>
                  100% money back guaranteed.
                </p>
              </div>

              <a href="#" className="button--link button--flex">
                Shop Now <i className="ri-arrow-right-down-line button__icon"></i>
              </a>
            </div>
          </div>
        </section>

        {/* Steps Section */}
        <section className="steps section container">
          <div className="steps__bg">
            <h2 className="section__title-center steps__title">
              Steps to start your <br /> plants off right
            </h2>

            <div className="steps__container grid">
              <div className="steps__card">
                <div className="steps__card-number">01</div>
                <h3 className="steps__card-title">Choose Plant</h3>
                <p className="steps__card-description">
                  We have several varieties plants you can choose from.
                </p>
              </div>

              <div className="steps__card">
                <div className="steps__card-number">02</div>
                <h3 className="steps__card-title">Place an order</h3>
                <p className="steps__card-description">
                  Once your order is set, we move to the next step which is the shipping.
                </p>
              </div>

              <div className="steps__card">
                <div className="steps__card-number">03</div>
                <h3 className="steps__card-title">Get plants delivered</h3>
                <p className="steps__card-description">
                  Our delivery process is easy, you receive the plant direct to your door.
                </p>
              </div>
            </div>
          </div>
        </section>

        <section class="product section container" id="products">
                <h2 class="section__title-center">
                    Check out our <br/> other products
                </h2>

                <p class="product__description">
                    Here are some selected yeilds from our plantation, all are in excellent 
                    condition and has a long life span. Buy and enjoy best quality.
                </p>

                <div class="product__container grid">
                    <article class="product__card">
                        <div class="product__circle"></div>
                        <img src={product1Image } alt="" className="product__img" />

                        <h3 class="product__title">Coffee</h3>
                        <span class="product__price">$10.99</span>

                        <button class="button--flex product__button">
                            <i class="ri-shopping-bag-line"></i>
                        </button>
                    </article>

                    <article class="product__card">
                        <div class="product__circle"></div>

                        <img src={product2Image } alt="" className="product__img" />

                        <h3 class="product__title">Sugarcane</h3>
                        <span class="product__price">$20.99</span>

                        <button class="button--flex product__button">
                            <i class="ri-shopping-bag-line"></i>
                        </button>
                    </article>

                    <article class="product__card">
                        <div class="product__circle"></div>

                        <img src={product3Image } alt="" className="product__img" />

                        <h3 class="product__title">Coconut</h3>
                        <span class="product__price">$10.99</span>

                        <button class="button--flex product__button">
                            <i class="ri-shopping-bag-line"></i>
                        </button>
                    </article>

                    <article class="product__card">
                        <div class="product__circle"></div>

                        <img src={product4Image } alt="" className="product__img" />

                        <h3 class="product__title">Banana</h3>
                        <span class="product__price">$5.99</span>

                        <button class="button--flex product__button">
                            <i class="ri-shopping-bag-line"></i>
                        </button>
                    </article>

                    <article class="product__card">
                        <div class="product__circle"></div>

                        <img src={product5Image } alt="" className="product__img" />

                        <h3 class="product__title">Cotton</h3>
                        <span class="product__price">$11.99</span>

                        <button class="button--flex product__button">
                            <i class="ri-shopping-bag-line"></i>
                        </button>
                    </article>

                    <article class="product__card">
                        <div class="product__circle"></div>

                        <img src={product6Image } alt="" className="product__img" />

                        <h3 class="product__title">Wheat</h3>
                        <span class="product__price">$40.99</span>

                        <button class="button--flex product__button">
                            <i class="ri-shopping-bag-line"></i>
                        </button>
                    </article>
                </div>
        </section>

        <section className="questions section" id="faqs">
          <h2 className="section__title-center questions__title container">
            Some common questions <br /> were often asked
          </h2>

          <div className="questions__container container grid">
            <div class="questions__group">
                        <div class="questions__item">
                            <header class="questions__header">
                                <i class="ri-add-line questions__icon"></i>
                                <h3 class="questions__item-title">
                                    My flowers are falling off or dying?
                                </h3>
                            </header>

                            <div class="questions__content">
                                <p class="questions__description">
                                    Plants are easy way to add color energy and transform your 
                                    space but which planet is for you. Choosing the right plant.
                                </p>
                            </div>
                        </div>

                        <div class="questions__item">
                            <header class="questions__header">
                                <i class="ri-add-line questions__icon"></i>
                                <h3 class="questions__item-title">
                                    What causes leaves to become pale?
                                </h3>
                            </header>

                            <div class="questions__content">
                                <p class="questions__description">
                                    Plants are easy way to add color energy and transform your 
                                    space but which planet is for you. Choosing the right plant.
                                </p>
                            </div>
                        </div>

                        <div class="questions__item">
                            <header class="questions__header">
                                <i class="ri-add-line questions__icon"></i>
                                <h3 class="questions__item-title">
                                    What causes brown crispy leaves?
                                </h3>
                            </header>

                            <div class="questions__content">
                                <p class="questions__description">
                                    Plants are easy way to add color energy and transform your 
                                    space but which planet is for you. Choosing the right plant.
                                </p>
                            </div>
                        </div>
                    </div>

                    <div class="questions__group">
                        <div class="questions__item">
                            <header class="questions__header">
                                <i class="ri-add-line questions__icon"></i>
                                <h3 class="questions__item-title">
                                    How do i choose a plant?
                                </h3>
                            </header>

                            <div class="questions__content">
                                <p class="questions__description">
                                    Plants are easy way to add color energy and transform your 
                                    space but which planet is for you. Choosing the right plant.
                                </p>
                            </div>
                        </div>

                        <div class="questions__item">
                            <header class="questions__header">
                                <i class="ri-add-line questions__icon"></i>
                                <h3 class="questions__item-title">
                                    How do I change the pots?
                                </h3>
                            </header>

                            <div class="questions__content">
                                <p class="questions__description">
                                    Plants are easy way to add color energy and transform your 
                                    space but which planet is for you. Choosing the right plant.
                                </p>
                            </div>
                        </div>

                        <div class="questions__item">
                            <header class="questions__header">
                                <i class="ri-add-line questions__icon"></i>
                                <h3 class="questions__item-title">
                                    Why are gnats flying around my plant?
                                </h3>
                            </header>

                            <div class="questions__content">
                                <p class="questions__description">
                                    Plants are easy way to add color energy and transform your 
                                    space but which planet is for you. Choosing the right plant.
                                </p>
                            </div>
                        </div>
                    </div>
            {/* You can map through your FAQ data and render FAQ items here */}
          </div>
        </section>

        {/* Contact Section */}
        <section className="contact section container" id="contact">
          <div className="contact__container grid">
            <div className="contact__box">
              <h2 className="section__title">
                Reach out to us today <br /> via any of the given <br /> information
              </h2>

              <div className="contact__data">
                <div className="contact__information">
                  <h3 className="contact__subtitle">Call us for instant support</h3>
                  <span className="contact__description">
                    <i className="ri-phone-line contact__icon"></i>
                    +91 9787415172
                  </span>
                </div>

                <div className="contact__information">
                  <h3 className="contact__subtitle">Write us by mail</h3>
                  <span className="contact__description">
                    <i className="ri-mail-line contact__icon"></i>
                    mdanasbinsaleem@email.com
                  </span>
                </div>
              </div>
            </div>

            <form action="" className="contact__form">
              <div className="contact__inputs">
                <div className="contact__content">
                  <input type="email" placeholder=" " className="contact__input" />
                  <label htmlFor="" className="contact__label">Email</label>
                </div>

                <div className="contact__content">
                  <input type="text" placeholder=" " className="contact__input" />
                  <label htmlFor="" className="contact__label">Subject</label>
                </div>

                <div className="contact__content contact__area">
                  <textarea name="message" placeholder=" " className="contact__input"></textarea>
                  <label htmlFor="" className="contact__label">Message</label>
                </div>
              </div>

              <button className="button button--flex">
                Send Message
                <i className="ri-arrow-right-up-line button__icon"></i>
              </button>
            </form>
          </div>
        </section>
      </main>
      </div>
     <br/><br/><br/>

        <div className="footer__container container grid">
            <div className="footer__content">
                <a href="#" className="footer__logo">
                    <i className="ri-leaf-line footer__logo-icon"></i> AgroAcres
                </a>

                <h3 className="footer__title">
                    Subscribe to our newsletter <br /> to stay updated
                </h3>

                <div className="footer__subscribe">
                    <input type="email" placeholder="Enter your email" className="footer__input" />

                    <button className="button button--flex footer__button">
                        Subscribe
                        <i className="ri-arrow-right-up-line button__icon"></i>
                    </button>
                </div>
            </div>

            <div className="footer__content">
                <h3 className="footer__title">Our Address</h3>

                <ul className="footer__data">
                    <li className="footer__information">1234 - Perundurai</li>
                    <li className="footer__information">La Libertad - 43210</li>
                    <li className="footer__information">123-456-789</li>
                </ul>
            </div>

            <div className="footer__content">
                <h3 className="footer__title">Contact Us</h3>

                <ul className="footer__data">
                    <li className="footer__information">+91 9787415172</li>
                    
                    <div className="footer__social">
                        <a href="https://www.facebook.com/" className="footer__social-link">
                            <i className="ri-facebook-fill"></i>
                        </a>
                        <a href="https://www.instagram.com/" className="footer__social-link">
                            <i className="ri-instagram-line"></i>
                        </a>
                        <a href="https://twitter.com/" className="footer__social-link">
                            <i className="ri-twitter-fill"></i>
                        </a>
                    </div>
                </ul>
            </div>

            <div className="footer__content">
                <h3 className="footer__title">
                    We accept all credit cards
                </h3>

                <div className="footer__cards">
                    <img src={card1Image} alt="" className="footer__card" />
                    <img src={card2Image} alt="" className="footer__card" />
                    <img src={card3Image} alt="" className="footer__card" />
                    <img src={card4Image} alt="" className="footer__card" />
                </div>
            </div>

            <p className="footer__copy"> &copy;Copyright. All rights reserved</p>
        </div>
    

    </Fragment>
  );
}


function App() {

  const [loggedin,setLoggedin] = useState(false);

const log_in = ()=>{
  setLoggedin(!loggedin);
}
  return (
    
    <Router>
    <div className={`App`}>
    <header className="header" id="header">
      <nav class="nav container">
        <Link className="nav__logo" to="/">
          <i class="ri-leaf-line nav__logo-icon"></i> AgroAcres
        </Link>
                <div class="nav__menu" id="nav-menu">
                    <ul class="nav__list">
                        <li class="nav__item">
                            <a href="#home" class="nav__link active-link">Home</a>
                        </li>
                        <li class="nav__item">
                            <a href="#about" class="nav__link">About</a>
                        </li>
                        <li class="nav__item">
                            <a href="#products" class="nav__link">Products</a>
                        </li>
                        <li class="nav__item">
                            <a href="#faqs" class="nav__link">FAQs</a>
                        </li>
                        <li class="nav__item">
                            <a href="#contact" class="nav__link">Contact Us</a>
                        </li>
                        {loggedin ? <></>:<><li class="nav__item">
                          <Link class="nav__link" to="/login">Login</Link>
                        </li>
                        <li class="nav__item">
                          <Link class="nav__link" to="/signup">Sign Up</Link>
                        </li></>}
                        
                    </ul>

                  
                    <div class="nav__close" id="nav-close">
                        <i class="ri-close-line"></i>
                    </div>
                </div>
            </nav>
    </header>
    </div>
      <Routes>
          <Route exact path="/login" element={<Login log_in={log_in}/>} />
          <Route exact path="/signup" element={<Register log_in={log_in}/>} />
          <Route exact path="/" Component={Screen} />
      </Routes>
    </Router>
      
      
     
  );
}


export default App;
