import React, { useState, useEffect } from "react";
import swal from "sweetalert";
import { Button, TextField, Link } from "@mui/material";
import { withRouter } from "./utils";

const Register = (props) => {
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const onChange = (e) => {
    if (e.target.name === "username") {
      setUsername(e.target.value);
    }else if (e.target.name === "email") {
      setEmail(e.target.value);
    } else if (e.target.name === "password") {
      setPassword(e.target.value);
    }
  };

  const register = () => {
    fetch("http://localhost:5000/users/signup", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        username:username,
        email:email,
        password:password,
      }),
    })
      .then((response) => response.json())
      .then((data) => {
        if(username===data.username){
          swal({
            text: `Welcome ${data.username}`,
            icon: "success",
            type: "success",
          });
          props.navigate("/");
          props.log_in();
        }
        else{
          swal({
            text: "User already exist",
            icon: "error",
            type: "error",
          });
        }
      })
      .catch((err) => {
        swal({
          text: err.errorMessage,
          icon: "error",
          type: "error",
        });
      });
  };

  useEffect(() => {
  }, []);

  return (
    <div style={{ marginTop: "200px" }}>
      <div>
        <h2>Register</h2>
      </div>

      <div>
        <TextField
          id="standard-basic"
          type="text"
          autoComplete="off"
          name="username"
          value={username}
          onChange={onChange}
          placeholder="User Name"
          required
        />
        <br />
        <br />
        <TextField
          id="standard-basic"
          type="text"
          autoComplete="off"
          name="email"
          value={email}
          onChange={onChange}
          placeholder="E-mail"
          required
        />
        <br />
        <br />
        <TextField
          id="standard-basic"
          type="password"
          autoComplete="off"
          name="password"
          value={password}
          onChange={onChange}
          placeholder="Password"
          required
        />
        <br />
        <br />
        <Button
          className="button_style"
          variant="contained"
          color="primary"
          size="small"
          disabled={username === ""|| email === "" || password === ""}
          onClick={register}
        >
          Register
        </Button>{" "}
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <Link
          component="button"
          style={{ fontFamily: "inherit", fontSize: "inherit" }}
          onClick={() => {
            props.navigate("/login");
          }}
        >
          Login
        </Link>
      </div>
    </div>
  );
};

export default withRouter(Register);
