import React, { useState, useEffect } from "react";
import swal from "sweetalert";
import { Button, TextField, Link } from "@mui/material";
import { withRouter } from "./utils";

const Login = (props) => {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");

  const onChange = (e) => {
    if (e.target.name === "username") {
      setUsername(e.target.value);
    } else if (e.target.name === "password") {
      setPassword(e.target.value);
    }
  };

  const login = () => {

    fetch("http://localhost:5000/users/login", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        username:username,
        password: password,
      }),
    })
      .then((response) => response.json())
      .then((data) => {
        if(username===data.username){
          swal({
            text: `Logged in`,
            icon: "success",
            type: "success",
          });
          props.navigate("/");
          props.log_in();
        }
        else{
          swal({
            text: "Username or password incorrect",
            icon: "error",
            type: "error",
          });
        }
      })
      .catch((err) => {
        swal({
          text: err.errorMessage,
          icon: "error",
          type: "error",
        });
      });
  };

  useEffect(() => {
  }, []);

  return (
    <div style={{ marginTop: "200px" }}>
      <div>
        <h2>Login</h2>
      </div>

      <div>
        <TextField
          id="standard-basic"
          type="text"
          autoComplete="off"
          name="username"
          value={username}
          onChange={onChange}
          placeholder="User Name"
          required
        />
        <br />
        <br />
        <TextField
          id="standard-basic"
          type="password"
          autoComplete="off"
          name="password"
          value={password}
          onChange={onChange}
          placeholder="Password"
          required
        />
        <br />
        <br />
        <Button
          className="button_style"
          variant="contained"
          color="primary"
          size="small"
          disabled={username === "" || password === ""}
          onClick={login}
        >
          Login
        </Button>{" "}
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <Link
          component="button"
          style={{ fontFamily: "inherit", fontSize: "inherit" }}
          onClick={() => {
            props.navigate("/signup");
          }}
        >
          Register
        </Link>
      </div>
    </div>
  );
};

export default withRouter(Login);
